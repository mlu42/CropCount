package ipcm.tool.kit;

import java.util.GregorianCalendar;

public class Dates {

    // Then, writing toString method for GregorianCalendar

    public String formatDate(GregorianCalendar d){

        String dayOfWeek = ItoSDayOfWeek(d.get(GregorianCalendar.DAY_OF_WEEK));
        String dayOfMonth = ItoSDayOfMonth(d.get(GregorianCalendar.DAY_OF_MONTH));
        String month = ItoSMonth(d.get(GregorianCalendar.MONTH));
        String year = ItoSYear(d.get(GregorianCalendar.YEAR));

        int[] t = new int[3];
        t[0] = d.get(GregorianCalendar.HOUR);
        t[1] = d.get(GregorianCalendar.MINUTE);
        t[2] = d.get(GregorianCalendar.SECOND);

        String time = ItoSTime(t);
        String ampm = ItoSAMPM(d.get(GregorianCalendar.AM_PM));

        return dayOfWeek + ", " + dayOfMonth + " " + month + " " + year + " " + time + ampm;

    }

    public int StoIDayOfWeek(String s){
        return -1;
    }

    public String ItoSDayOfWeek(int i){

        switch(i){
            case 1: return "Sun";
            case 2: return "Mon";
            case 3: return "Tue";
            case 4: return "Wed";
            case 5: return "Thu";
            case 6: return "Fri";
            case 7: return "Sat";
            //////////////////////
            default: return "Sun";
        }

    }

    public int StoIDayOfMonth(String s){
        int d = -1;

        try{
            d = Integer.parseInt(s);
        }catch(Exception e){
            d = 1;
        }

        return d;
    }

    public String ItoSDayOfMonth(int i){

        return ((Integer)i).toString();

    }

    public int StoIMonth(String s){
        int d = -1;

        if(s.equals("Jan"))
            d = 1;
        if(s.equals("Feb"))
            d = 2;
        if(s.equals("Mar"))
            d = 3;
        if(s.equals("Apr"))
            d = 4;
        if(s.equals("May"))
            d = 5;
        if(s.equals("Jun"))
            d = 6;
        if(s.equals("Jul"))
            d = 7;
        if(s.equals("Aug"))
            d = 8;
        if(s.equals("Sep"))
            d = 9;
        if(s.equals("Oct"))
            d = 10;
        if(s.equals("Nov"))
            d = 11;
        if(s.equals("Dec"))
            d = 12;

        if(d == -1)
            d = 1;

        return d;
    }

    public String ItoSMonth(int i){

        switch(i){
            case 1: return "Jan";
            case 2: return "Feb";
            case 3: return "Mar";
            case 4: return "Apr";
            case 5: return "May";
            case 6: return "Jun";
            case 7: return "Jul";
            case 8: return "Aug";
            case 9: return "Sep";
            case 10: return "Oct";
            case 11: return "Nov";
            case 12: return "Dec";
            //////////////////////
            default: return "Jan";
        }

    }

    public int StoIYear(String s){
        int d = -1;

        try{
            d = Integer.parseInt(s);
        }catch(Exception e){
            d = 2013;
        }

        return d;
    }

    public String ItoSYear(int i){

        return ((Integer)i).toString();

    }

    public int[] StoITime(String s){
        int[] time = new int[3];

        try{
            String[] times = s.split(":");
            time[0] = Integer.parseInt(times[0]);
            time[1] = Integer.parseInt(times[1]);
            time[2] = Integer.parseInt(times[2]);
        }catch(Exception e){
            time[0] = time[1] = time[2] = 0;
        }

        return time;
    }

    public String ItoSTime(int[] i){

        try{
            String hour = ((Integer)i[0]).toString();
            String minute = ((Integer)i[1]).toString();
            String second = ((Integer)i[2]).toString();

            if(minute.length() == 1)
                minute = "0" + minute;
            if(second.length() == 1)
                second = "0" + second;

            return hour + ":" + minute; // + ":" + second;
        }catch(Exception e){
            return "12:00";
        }

    }

    public int StoIAMPM(String s){

        if(s.equals("AM"))
            return 0;

        return 1;

    }

    public String ItoSAMPM(int i){

        if(i == 0)
            return "AM";

        return "PM";

    }

}
