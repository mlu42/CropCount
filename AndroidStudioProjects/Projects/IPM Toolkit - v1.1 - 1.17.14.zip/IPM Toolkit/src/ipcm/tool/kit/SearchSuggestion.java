package ipcm.tool.kit;

public class SearchSuggestion {
    public String id;
    public String value;
    public String usename;

    public SearchSuggestion(String id, String value, String usename){
        this.id = id;
        this.value = value;
        this.usename = usename;
    }
}
