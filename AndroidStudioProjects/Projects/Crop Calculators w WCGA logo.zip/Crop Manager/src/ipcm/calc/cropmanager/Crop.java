package ipcm.calc.cropmanager;

public class Crop {

	private String name;
	
	public Crop(String n){
		name = n;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
	
}
