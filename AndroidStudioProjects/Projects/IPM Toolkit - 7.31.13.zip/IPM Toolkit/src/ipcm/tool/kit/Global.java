package ipcm.tool.kit;

/*
This class was originally intended to be a "helper" class of sorts for global
things, but never really go going or lived up to its full potential (if it
ever had any to begin with).
 */

public class Global {

	public static int searchOption = 0;
	
}
