package ipcm.tool.kit;

public class NewsFeed {

    public String url;
    public String feedType;

    public NewsFeed(String url, String feedType){
        this.url = url;
        this.feedType = feedType;
    }

}
