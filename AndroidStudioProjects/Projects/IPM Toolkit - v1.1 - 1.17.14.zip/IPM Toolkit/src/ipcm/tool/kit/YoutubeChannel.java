package ipcm.tool.kit;

public class YoutubeChannel {

    public String url;

    public YoutubeChannel(String url){
        this.url = url;
    }

}
