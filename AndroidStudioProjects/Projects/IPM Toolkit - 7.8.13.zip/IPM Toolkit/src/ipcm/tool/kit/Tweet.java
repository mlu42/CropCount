package ipcm.tool.kit;

import java.net.URL;

public class Tweet {

	private String user;
	private String text;
	private String id;
	private URL link;
    private URL thumbnailURL;

    public Tweet() {
		setUser("");
		setText("");
		setId("");
	}
	
	public Tweet(String _user, String _text, String _id) {
		setUser(_user);
		setText(_text);
		setId(_id);
		try{
			setLink(new URL("http://twitter.com/" + user + "/status/" + id));			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

    public Tweet(String _user, String _text, String _id, String _thumb) {
        setUser(_user);
        setText(_text);
        setId(_id);
        try{
            setLink(new URL("http://twitter.com/" + user + "/status/" + id));
            setThumbnailURL(new URL(_thumb));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

	public String getUser()	{
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public URL getLink() {
		return link;
	}

	public void setLink(URL link) {
		this.link = link;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

    public URL getThumbnailURL() {
        return thumbnailURL;
    }

    public void setThumbnailURL(URL thumbnailURL) {
        this.thumbnailURL = thumbnailURL;
    }
	
}
