package ipcm.calc.cropmanager;

import android.app.Activity;

public class CalculatorActivity extends Activity {

    public void calculate(){

    }

}
