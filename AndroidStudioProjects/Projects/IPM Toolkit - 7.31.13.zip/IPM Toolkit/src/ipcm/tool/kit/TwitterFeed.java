package ipcm.tool.kit;

public class TwitterFeed {

    public String url;

    public TwitterFeed(String url){
        this.url = url;
    }

}
